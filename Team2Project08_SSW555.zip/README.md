# Agile_Methods_Project
CS 555WS - Group 2
Collaborators: Avaneesh Kolluri, Pratim Patel, Zach George, Srikanth Uppada, Erick Lim.
