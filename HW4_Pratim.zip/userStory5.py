from project2 import processGedFile



def Story5(file, ID):
    individuals,famDict = processGedFile(file)
    if(famDict[ID] != 'NA'):
        if(famDict[ID].Get_married() != 'NA'):
           marriedDate = famDict[ID].Get_married()
           print("Married Date: " + str(marriedDate))
           
        if(famDict[ID].Get_divorced() != 'NA'):
            divorcedDate = famDict[ID].Get_divorced()
            print("Divorced Date: " + str(divorcedDate))
            if(marriedDate>divorcedDate):
                return False
    return True

result = Story5("divorcebeforewedding.ged", "F1")
print(result)
