import unittest
from userStory5 import Story5
import project2
class TestuserStory5Class(unittest.TestCase):

    def test_story05test1(self):
        self.assertEqual(Story5("divorcebeforewedding.ged", "F1"), False)
    def test_story05test2(self):
        self.assertEqual(Story5("weddingbeforedivorce.ged", "F1"), True)
    def test_story05test3(self):
        self.assertEqual(Story5("death_divorcebefore.ged", "F1"), False)
    def test_story05test4(self):
        self.assertEqual(Story5("parents_weddingbefore.ged", "F2"), True)
    def test_story05test5(self):
        self.assertEqual(Story5("parents_divorcebefore.ged", "F2"), False)

if __name__ == "__main__":
    unittest.main()
